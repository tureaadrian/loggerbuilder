from setuptools import setup

setup(name='loggerbuilder',
      version='0.1',
      description='Logger Builder ',
      url='https://github.com/tureaadrian/loggerbuilder',
      author='Adrian Turea',
      author_email='',
      license='MIT',
      packages=['loggerbuilder'],
      zip_safe=False)